import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderstatus',
  templateUrl: './orderstatus.page.html',
  styleUrls: ['./orderstatus.page.scss'],
})
export class OrderstatusPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
